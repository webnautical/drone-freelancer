
import utilities from './utilities';
const menuItems = {
  items: [
    utilities,
  ]
};

export default menuItems;
