// project import

// import pages from './pages';

// import dashboard from './dashboard';

// import utilities from './utilities';

// import support from './support';

import PosterTab from './PosterTab';

// ==============================|| MENU ITEMS ||============================== //

const menuItems1 = {
  items: [PosterTab]
};

export default menuItems1;
